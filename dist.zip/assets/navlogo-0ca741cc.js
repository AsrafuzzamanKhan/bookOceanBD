const o="/assets/navlogo-b8cc3247.png";export{o as l};
